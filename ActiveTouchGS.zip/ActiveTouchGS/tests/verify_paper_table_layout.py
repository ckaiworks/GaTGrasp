#!/usr/bin/env python3
"""Verify that Tables 2--4 map to real, syntactically valid release files."""

from __future__ import annotations

import ast
import csv
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TABLES = {
    "table2": ROOT / "experiments" / "table2_primary_selector",
    "table3": ROOT / "experiments" / "table3_tactile_verification",
    "table4": ROOT / "experiments" / "table4_selector_ablations",
}
EXPECTED_ROWS = {"table2": 9, "table3": 4, "table4": 17}


def resolve_entry(table_dir: Path, value: str) -> Path | None:
    value = value.strip()
    if not value or value == "same trainer evaluation":
        return None
    # A non-neural entry may append its CLI arguments in the display column.
    candidate = value.split(" --method ", 1)[0]
    return (table_dir / candidate).resolve()


def main() -> None:
    checked: set[Path] = set()
    for name, table_dir in TABLES.items():
        methods_path = table_dir / "methods.csv"
        results_path = table_dir / "results.csv"
        assert methods_path.is_file(), methods_path
        assert results_path.is_file(), results_path

        with methods_path.open(newline="", encoding="utf-8-sig") as handle:
            methods = list(csv.DictReader(handle))
        with results_path.open(newline="", encoding="utf-8-sig") as handle:
            results = list(csv.DictReader(handle))

        assert len(methods) == EXPECTED_ROWS[name], (name, len(methods))
        assert len(results) == EXPECTED_ROWS[name], (name, len(results))

        for row in methods:
            for column in ("train_entry", "evaluation_entry"):
                if column not in row:
                    continue
                path = resolve_entry(table_dir, row[column])
                if path is None:
                    continue
                assert path.is_file(), f"{name} {column}: {path}"
                checked.add(path)

    for path in ROOT.rglob("*.py"):
        if "__pycache__" in path.parts:
            continue
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))

    print(
        "PAPER_TABLE_LAYOUT_PASS "
        f"tables={len(TABLES)} mapped_files={len(checked)} python_ast=PASS"
    )


if __name__ == "__main__":
    main()
