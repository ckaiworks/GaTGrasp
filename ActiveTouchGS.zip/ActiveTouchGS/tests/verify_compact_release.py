#!/usr/bin/env python3
"""Static acceptance gate for the compact GitHub release."""

from __future__ import annotations

import ast
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

required = [
    "README.md",
    "requirements.txt",
    "configs/training_paths.example.env",
    "scripts/dataset/validate_final_dataset.py",
    "scripts/dataset/materialize_runtime_indexes.py",
    "scripts/stage1/run_stage1_final_fivefold.sh",
    "scripts/stage2/run_stage2_selected_fullgs_fivefold.sh",
    "src/stage1/final/train_stage1_old12_fullcorridor_annealedSelect_v1.py",
    "src/stage2/final/train_stage2_fullgs_touch.py",
    "src/evaluation/final/infer_stage1_fivefold.py",
    "src/evaluation/final/run_cascade.py",
    "reports/final_stage1_tables/table2_primary_selector_comparison.csv",
    "reports/final_stage1_tables/table4_stage1_clean_ablations.csv",
]

for relative in required:
    path = ROOT / relative
    if not path.is_file():
        raise RuntimeError(f"MISSING_REQUIRED_FILE={relative}")

for forbidden in (
    "third_party",
    "src/physical_sampling",
    "src/reconstruction",
    "src/gs_features",
    "requirements-sampling.txt",
    "requirements-mvsgs.txt",
):
    if (ROOT / forbidden).exists():
        raise RuntimeError(f"FORBIDDEN_COMPACT_RELEASE_ENTRY={forbidden}")

python_files = sorted(ROOT.rglob("*.py"))
for path in python_files:
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))

runtime_roots = [ROOT / "src", ROOT / "scripts", ROOT / "configs"]
for base in runtime_roots:
    for path in base.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() not in {".py", ".sh", ".env", ".md"}:
            continue
        text = path.read_text(encoding="utf-8", errors="replace")
        if "/root/autodl-tmp/" in text or "/root/miniconda3/" in text:
            raise RuntimeError(f"SERVER_ABSOLUTE_PATH={path.relative_to(ROOT)}")

print(f"PYTHON_STATIC_COMPILE_PASS={len(python_files)}")
print("NO_SAMPLING_RECONSTRUCTION_THIRD_PARTY_PASS")
print("NO_SERVER_ABSOLUTE_RUNTIME_PATH_PASS")
print("COMPACT_GITHUB_RELEASE_ACCEPTANCE_PASS")
