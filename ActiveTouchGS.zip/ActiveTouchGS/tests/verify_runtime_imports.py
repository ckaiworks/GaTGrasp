#!/usr/bin/env python3
"""No-GPU import and CLI smoke checks for the public runtime environment."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import numpy
import PIL
import torch
import torchvision


ROOT = Path(__file__).resolve().parents[1]

EXPECTED_VERSIONS = {
    "torch": "2.7.0+cu128",
    "torchvision": "0.22.0+cu128",
    "numpy": "1.23.5",
    "Pillow": "11.3.0",
}

ACTUAL_VERSIONS = {
    "torch": torch.__version__,
    "torchvision": torchvision.__version__,
    "numpy": numpy.__version__,
    "Pillow": PIL.__version__,
}

for name, expected in EXPECTED_VERSIONS.items():
    actual = ACTUAL_VERSIONS[name]
    if actual != expected:
        raise RuntimeError(f"VERSION_MISMATCH {name}: {actual} != {expected}")
    print(f"VERSION_PASS {name}={actual}")

entries = [
    ROOT / "src/stage1/final/train_stage1_old12_fullcorridor_annealedSelect_v1.py",
    ROOT / "src/stage2/final/train_stage2_fullgs_touch.py",
    ROOT / "src/evaluation/final/infer_stage1_fivefold.py",
    ROOT / "src/evaluation/final/run_cascade.py",
]

for entry in entries:
    completed = subprocess.run(
        [sys.executable, str(entry), "--help"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"CLI_IMPORT_FAILED {entry.relative_to(ROOT)}\n{completed.stderr}"
        )
    print(f"CLI_IMPORT_PASS {entry.relative_to(ROOT)}")

print(f"CUDA_AVAILABLE={torch.cuda.is_available()}")
print("RUNTIME_IMPORT_ACCEPTANCE_PASS")
